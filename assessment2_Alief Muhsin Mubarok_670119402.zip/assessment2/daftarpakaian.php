<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
 
	<h2>CRUD DATA PAKAIAN</h2>
	<br/>
<!-- <a href="index.php">KEMBALI</a> -->
	<br/>
	<br/>
	<h3>TAMBAH DATA PAKAIAN</h3>
	<form method="post" action="daftarpakaian_proses.php" enctype="multipart/form-data">
		<table>
			<tr>			
				<td>Nama Barang</td>
				<td><input type="text" name="nama_barang"></td>
			</tr>
			<tr>
				<td>Harga</td>
				<td><input type="text" name="harga"></td>
			</tr>
			<tr>
				<td>Gambar</td>
				<td><input type="file" name="gambar"></td>
			</tr>		
				<td></td>
				<td><input type="submit" value="SIMPAN" name="submit"></td>
			</tr>
					
		</table>
	</form>
</body>
</html>