<?php 
// koneksi database
include 'koneksi.php';
 
// menangkap data yang di kirim dari form
$namabarang = $_POST['nama_barang'];
$harga = $_POST['harga'];
$gambar = $_POST['gambar'];
 
// menginput data ke database
mysqli_query($koneksi,"insert into pakaian values('','$namabarang','$harga','gambar')");
 
// mengalihkan halaman kembali ke index.php
header("location:hasildaftarpakaian.php");
 
?>