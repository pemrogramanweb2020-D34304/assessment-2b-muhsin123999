<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
 
	<br/>
	<a href="hasildaftarpakaian.php">KEMBALI</a>
	<br/>
	<br/>
	<h3>EDIT DATA PAKAIAN</h3>
 
	<?php
	include 'koneksi.php';
	$id = $_GET['id'];
	$data = mysqli_query($koneksi,"select * from pakaian where id='$id'");
	while($d = mysqli_fetch_array($data)){
		?>
		<form method="post" action="proses_editpakaian.php">
			<table>
				<tr>			
					<td>Nama</td>
					<td>
						<input type="hidden" name="id" value="<?php echo $d['id']; ?>">
						<input type="text" name="nama_barang" value="<?php echo $d['nama_pakaian']; ?>">
					</td>
				</tr>
				<tr>
					<td>NIM</td>
					<td><input type="text" name="harga" value="<?php echo $d['harga']; ?>"></td>
				</tr>
				<tr>
					<td>Gambar</td>
					<td><input type="file" name="gambar" value="<?php echo $d['gambar']; ?>"></td>
				</tr>
				<tr>
					<td></td>
					<td><input type="submit" value="SIMPAN"></td>
				</tr>		
			</table>
		</form>
		<?php 
	}
	?>
 
</body>
</html>
