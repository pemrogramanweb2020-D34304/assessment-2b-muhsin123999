<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
 
	<h2>Daftar Pakaian</h2>
	<br/>
	<a href="daftarpakaian.php">+ TAMBAH Pakaian</a>
	<br/>
	<br/>
	<table border="1">
		<tr>
			<th>NO</th>
			<th>Nama Barang</th>
			<th>Harga</th>
			<th>Gambar</th>
			<th>Aksi</th>
		</tr>
		<?php 
		include 'koneksi.php';
		$no = 1;
		$data = mysqli_query($koneksi,"select * from pakaian");
		while($d = mysqli_fetch_array($data)){
			?>
			<tr>
				<td><?php echo $no++; ?></td>
				<td><?php echo $d['nama_pakaian']; ?></td>
				<td><?php echo $d['harga']; ?></td>
				<td><?php echo $d['gambar']; ?></td>
				<td>
					<a href="form_editdaftarpakaian.php?id=<?php echo $d['id']; ?>">EDIT</a>
					<a href="hapusdaftarpakaian.php?id=<?php echo $d['id']; ?>">HAPUS</a>
				</td>
			</tr>
			<?php 
		}
		?>
	</table>
</body>
</html>