<?php 
// koneksi database
include 'koneksi.php';
 
// menangkap data yang di kirim dari form
$id = $_POST['id'];
$nama = $_POST['nama_barang'];
$harga = $_POST['harga'];
$gambar = $_POST['gambar'];
// update data ke database
mysqli_query($koneksi,"update pakaian set nama_pakaian='$nama', harga='$harga', gambar='$gambar' where id='$id'");
 
// mengalihkan halaman kembali ke index.php
header("location:hasildaftarpakaian.php");
 
?>